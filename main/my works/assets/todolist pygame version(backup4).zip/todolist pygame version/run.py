import pygame
import sys
from pygame.locals import *
from data.engine import Object, RectFrame

class Game:
    def __init__(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((400, 500))
        self.clock = pygame.time.Clock()
        self.display = pygame.Surface((800,1000))
        self.assets = {
            "botton": pygame.image.load("data/img/botton.png")
        }
        self.botton_object1 = Object(self, (0, 0), 1, (0, 0))
        self.botton_object2 = Object(self, (0, 0), 1, (0, 300))
        self.botton_object3 = Object(self, (0, 0), 1, (0, 600))
        self.botton_object_frame = RectFrame(self, (500, 1000), 0.05, (50, 70), (0, 0), (0, 0))
        self.rect_frame = RectFrame(self, (780, 980)).rect()

    def run(self):
        while True:
            self.display.fill((255, 255, 255))
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN:
                    if event.key == K_LEFT:
                        self.botton_object_frame.vel[0] -= 12
                    elif event.key == K_RIGHT:
                        self.botton_object_frame.vel[0] += 12

                if event.type == MOUSEBUTTONDOWN:
                    if event.button == 4:
                        self.botton_object_frame.vel[1] += 12
                    elif event.button == 5:
                        self.botton_object_frame.vel[1] -= 12
                if event.type == MOUSEMOTION:
                    if self.botton_object_frame.pos[0] + self.botton_object_frame.width_and_height[0] > event.pos[0] * 2 > self.botton_object_frame.pos[0] and self.botton_object_frame.pos[1] + self.botton_object_frame.width_and_height[1] > event.pos[1] * 2 > self.botton_object_frame.pos[1]:
                        # print(event.rel, self.botton_object_frame.vel)
                        if event.buttons[0]:
                            self.botton_object_frame.vel[0] = list(event.rel)[0] * 4
                            self.botton_object_frame.vel[1] = list(event.rel)[1] * 4
                        #     self.botton_object_frame.pos[0] = event.pos[0] * 2 - self.botton_object_frame.width_and_height[0] / 2
                        #     self.botton_object_frame.pos[1] = event.pos[1] * 2 - self.botton_object_frame.width_and_height[1] / 2

            pygame.draw.rect(self.display, (255, 255, 255), self.rect_frame)

            button_surface = self.botton_object_frame.surface()
            button_surface.fill((255, 255, 255))

            self.botton_object1.render(surf=button_surface, asset=self.assets["botton"])
            self.botton_object2.render(surf=button_surface, asset=self.assets["botton"])
            self.botton_object3.render(surf=button_surface, asset=self.assets["botton"])

            self.botton_object_frame.update()
            self.botton_object_frame.render(surf=self.display, asset=button_surface)

            self.screen.blit(pygame.transform.scale(self.display, (400, 500)), (0, 0))
            pygame.display.update()
            self.clock.tick(90)

Game().run()