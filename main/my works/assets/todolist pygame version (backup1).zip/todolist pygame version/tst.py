import pygame
import sys

# 初始化 Pygame
pygame.init()

# 设置窗口大小
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Friction Example")

# 定义物体属性
position = pygame.Vector2(400, 300)
velocity = pygame.Vector2(5, 0)  # 初始速度
acceleration = pygame.Vector2(0, 0)
friction_coefficient = 0.1  # 摩擦系数

# 主循环
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()

    # 应用摩擦力
    if velocity.length() > 0:  # 只有在物体有速度时才应用摩擦力
        friction_force = -friction_coefficient * velocity.normalize()
        acceleration = friction_force

    # 更新速度和位置
    velocity += acceleration
    position += velocity

    # 填充背景色
    screen.fill((255, 255, 255))

    # 绘制物体
    pygame.draw.circle(screen, (0, 0, 255), (float(position.x), int(position.y)), 10)

    # 刷新屏幕
    pygame.display.flip()

    # 设置帧率
    pygame.time.Clock().tick(60)

# 退出 Pygame
pygame.quit()
