import pygame

class Object:
    def __init__(self, game, friction_coefficient, position, velocity, acceleration) -> None:
        self.game = game
        self.friction = friction_coefficient
        self.pos = list(position)
        self.vel = list(velocity)    # !ALL OF THIS ARE VECTORS!
        self.accel = list(acceleration)

    def update(self):
        if abs(self.vel[1]) > 0.5: # |v| > 0
            # normalized_vel = self.vel[1] / abs(self.vel[1]) # u = v / |v|
            self.accel[1] = round(-self.friction * self.vel[1], 4) # f_s = -fric * u
        elif abs(self.accel[1]) < 1:
            self.accel[1] = 0
            self.vel[1] = 0

        self.vel[1] = round(min(12, self.vel[1]), 4)
        self.vel[1] = round(max(-12, self.vel[1]), 4)

        self.vel[1] += self.accel[1]
        self.pos[1] += int(self.vel[1])

    def render(self):
        self.game.display.blit(self.game.assets["botton"], tuple(self.pos))
