import pygame
import sys
from pygame.locals import *
from data.engine import Object

class Game:
    def __init__(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((400, 500))
        self.clock = pygame.time.Clock()
        self.display = pygame.Surface((200, 250))
        self.assets = {
            "botton": pygame.image.load("data/img/botton.png")
        }
        self.botton_object = Object(self, 0.03, (70, 10), (0, 0), (0, 0))
        self.botton_object2 = Object(self, 0.06, (70, 40), (0, 0), (0, 0))
        self.botton_object3 = Object(self, 0.09, (70, 70), (0, 0), (0, 0))

    def run(self):
        while True:
            self.display.fill((255, 255, 255))
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == MOUSEBUTTONDOWN:
                    if event.button == 4:
                        self.botton_object.vel[1] += 6
                        self.botton_object2.vel[1] += 6
                        self.botton_object3.vel[1] += 6
                    elif event.button == 5:
                        self.botton_object.vel[1] += -6
                        self.botton_object2.vel[1] += -6
                        self.botton_object3.vel[1] += -6

            self.botton_object.update()
            self.botton_object.render()
            self.botton_object2.update()
            self.botton_object2.render()
            self.botton_object3.update()
            self.botton_object3.render()

            self.screen.blit(pygame.transform.scale(self.display, (500, 500)), (0, 0))
            pygame.display.update()
            self.clock.tick(60)

Game().run()