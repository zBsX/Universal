import pygame
import sys
from pygame.locals import *
from data.engine import Object, RectFrame, ObjectSurface

class Game:
    def __init__(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((500, 500))
        self.clock = pygame.time.Clock()
        self.display = pygame.Surface((1000,1000))
        self.assets = {
            "button": pygame.image.load("data/img/botton.png")
        }
        self.button = Object(self, width_and_height=(500, 250), friction_coefficient=0.05)
        self.button_detection_rect = RectFrame(self, width_and_height=(500, 250), friction_coefficient=0.05)
        self.button_detection_rect2 = RectFrame(self, width_and_height=(500, 270), position=(200, 200))

    def run(self):
        while True:
            self.display.fill((255, 255, 255))
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == MOUSEBUTTONDOWN:
                    if (self.button_detection_rect.pos[0] + self.button_detection_rect.width_and_height[0]) > event.pos[0]*2 > self.button_detection_rect.pos[0] and (self.button_detection_rect.pos[1] + self.button_detection_rect.width_and_height[1]) > event.pos[1]*2 > self.button_detection_rect.pos[1]:
                        self.button.holding = True
                        self.button_detection_rect.holding = True
                if event.type == MOUSEBUTTONUP:
                    self.button.holding = False
                    self.button_detection_rect.holding = False
                if event.type == MOUSEMOTION:
                    if event.buttons[0]:
                        self.button.holding = True
                        self.button.accel[0] = event.rel[0] / 6
                        self.button.accel[1] = event.rel[1] / 6
                        self.button.vel[0] += self.button.accel[0]
                        self.button.vel[1] += self.button.accel[1]
                        self.button_detection_rect.holding = True
                        self.button_detection_rect.accel[0] = event.rel[0] / 6
                        self.button_detection_rect.accel[1] = event.rel[1] / 6
                        self.button_detection_rect.vel[0] += self.button_detection_rect.accel[0]
                        self.button_detection_rect.vel[1] += self.button_detection_rect.accel[1]
                    else: self.button.holding = False; self.button_detection_rect.holding = False
                
            

            rect = self.button_detection_rect.rect()
            rect2 = self.button_detection_rect2.rect()
            pygame.draw.rect(self.display, (255, 255, 255), rect)
            pygame.draw.rect(self.display, (255, 200, 200), rect2)
            self.button_detection_rect.update()
            self.button.update()
            self.button.render(self.display, self.assets["button"])
                        
            if rect.colliderect(rect2) and not self.button_detection_rect.holding and not self.button.holding:
                # 确定碰撞方向
                dx = rect2.centerx - rect.centerx
                dy = rect2.centery - rect.centery

                # 检查发生碰撞的方向
                if abs(dx) - 250 > abs(dy):
                    # 水平碰撞
                    if dx < 0:
                        # rect2 在 rect 左侧（右侧碰撞）
                        self.button_detection_rect.vel[0] += 1
                        self.button.vel[0] += 1
                    else:
                        # rect2 在 rect 右侧（左侧碰撞）
                        self.button_detection_rect.vel[0] -= 1
                        self.button.vel[0] -= 1
                else:
                    # 垂直碰撞
                    if dy < 0:
                        # rect2 在 rect 下方（上侧碰撞）
                        self.button_detection_rect.vel[1] += 1
                        self.button.vel[1] += 1
                    else:
                        # rect2 在 rect 上方（下侧碰撞）
                        self.button_detection_rect.vel[1] -= 1
                        self.button.vel[1] -= 1

            

                
            


            self.screen.blit(pygame.transform.scale(self.display, (500, 500)), (0, 0))
            pygame.display.update()
            self.clock.tick(90)

Game().run()