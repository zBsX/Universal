2024/4/20 -> 2024/4/26
[+] Working on json file saving ->
[+] Fix overall stability (slider, taskslance, json_filesaving)

2024/4/26
[+] Working on json file saving ->

2024/4/26 -> 4/28
[+] Working on json file saving ->

2024/4/29
[+] Working on json file saving ->

2024/4/30
[+] Working on json file saving ->

2024/5/1 -> 2024/5/5
[] Spare Time

2024/5/5
[+] Working on json file saving ->

2024/5/6
[+] Working on json file saving 
    [+] Basic Saving-Loading JSON ->
[+] Overall stability

2024/5/7
[] Spare Time

2024/5/8
[+] Working on json file saving ->
    [+] Use dictionary instead of bare function local variable to store widgets into memory -> 

2024/5/9
[+] Using Serial Number method to delete specific Memory Address Widgets
[+] Troubleshooting: can't read more than "10" in data.json. 
    quote:
        # Get the actual <n> integer value in the max_task string
        n = int(max_task[5])  <- to get the index 5 of the string is just getting a single number.
        print("Max tasks count:", n)
    end quote.

2024/5/10
[+] Working on json file saving ->

2024/5/11
[+] Working on json file saving ->
    labeldict improvement, need to get it work
    fix the value reading Task_<serial_number> for mutiple numbers

[ ] <problems>: 
    [x] can't read more than "10" in data.json file;
    [x] can't precisely delete tasks (finding a solution to map the key and the value to <serial_number> and the tasks in the json file);
    [x] finding a counter to count new adding tasks;

2024/5/12
[x] Working on json file saving ->
[x] fix<problems>
[~] Overall stability
[ ] Release