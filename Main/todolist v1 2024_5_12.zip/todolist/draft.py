
# x = [1, 2, 3]
# y = [1, 2, 3]  # 创建了一个新的对象
# print(x is y)  # 输出 False，因为 x 和 y 引用了不同的对象

# x = y
# print(x is y)
# print(x is not y)  # 输出 True，因为 x 和 y 引用了不同的对象
# if (x is y):
#     print("w")

# # 逻辑运算符：
# string1, string2, string3 = {}, '', [] 
# non_null = string1 or string2 or string3
# print(non_null) # 输出 []，如果所有表达式都为假，则返回最后一个表达式的值。

# string1, string2, string3 = {}, 't', [] 
# non_null = string1 or string2 or string3
# print(non_null) # 输出 t，如果表达式的值为真，则返回该值 


# print((1,2,4) < (1,2,4,4))

# (1, 2, 3)              < (1, 2, 4)
# [1, 2, 3]              < [1, 2, 4]
# 'ABC' < 'C' < 'Pascal' < 'Python'
# (1, 2, 3, 4)           < (1, 2, 4)
# (1, 2)                 < (1, 2, -1)
# (1, 2, 3)             == (1.0, 2.0, 3.0)
# (1, 2, ('aa', 'ab'))   < (1, 2, ('abc', 'a'), 4)




# for iter, index in enumerate(range(counter)):  // 此操作会把同一个 局部变量 和 内存空间 的组件生成在一起
 

#             # for count in range(1, len(data[1]) + 1):
#             #     print("count:", count)
#             #     counter += count
            

#             Global_height += LIST_HEIGHT
#             print("global height:", Global_height)


#             t = ttk.Label(self.new_frame, text=Tasks_dict[f"Task_{iter}"], font=("", 20))
#             t.pack(anchor="w")
#             # print(iter)

#             # print(len(details))
#             # details Text
            
        
#             t2 = ttk.Label(self.new_frame, text=details[f"Detail_{index}"])
#             t2.pack(anchor="w"); 
#             # print(index)

#             sign = [iter]
#             print("init_sign:", sign)

#             # Finished Button
#             b = ttk.Button(self.new_frame, text=f"Finished{sign}", command=lambda: self.Finished(t, t2, b, sign))
#             b.pack(anchor="e")

            
            
#             local_sign[sign[0]] = f"Task_{iter}"
#             print("loaclsign:", local_sign)
            

            
# def f():

#     x = int(input("input:"))
#     l = [x]
#     print(l)

# while True:
#     f()


# def f(x):
    
#     def g():
        
        
#         def p():
            
            
#             print(x)
#         p()
#     g()

# f(1)

# print("1" in "deadawdawdaw1dawdawd2aw")

# for iter, index in enumerate(range(10)):
#             if (str(iter) in "task_1"[5]):
#                 print("ok", iter , index)
#             else:
#                 print("dosnt exist!!!")


                ### json file part
## 使用 for 循环 遍历counter 并且 if 判断是否存在于 读取的json文件中 
        # for iter, index in enumerate(range(counter)):
        #     if (str(iter) in str(Tasks_dict.keys())[5] and str(index) in str(details.keys()[7])):
        #         self.Iterate_Tasks(iter, index)
        #         local_sign[sign] = f"Task_{iter}"
        #         print("loaclsign:", local_sign)
        #     else:
        #         print("dosnt exist!!!")
        
        # print("localsign:", local_sign)



# for value, index in enumerate(range(10)):
#        print(value, index)



# # 导入必要的库
# import tkinter as tk
# from tkinter import scrolledtext

# # 创建主窗口
# root = tk.Tk()

# # 创建带有滚动条的文本框
# text = scrolledtext.ScrolledText(root)
# text.pack(expand=True, fill='both')

# # 定义函数禁用滚动条
# def disable_scrollbar():
#     text.configure(state='disabled')

# # 定义函数启用滚动条
# def enable_scrollbar():
#     text.configure(state='normal')

# # 创建禁用和启用滚动条的按钮
# disable_button = tk.Button(root, text="Disable Scrollbar", command=disable_scrollbar)
# disable_button.pack()

# enable_button = tk.Button(root, text="Enable Scrollbar", command=enable_scrollbar)
# enable_button.pack()

# # 进入主循环
# root.mainloop()










                ### load json file part (adjusting offset)


            # if (f"{local_counter}" in tasks_sign_list[local_counter] and f"{local_counter}" in details_sign_list[local_counter]): # index for tasks and Details, "<number>" 用来判断是否存在与 tasks Details dictionary
            #     print("// local_counter:", local_counter)
            #     self.IterateTasks(local_counter)


            # elif (f"{local_counter + 1}" in tasks_sign_list[local_counter]):
            #     self.IterateTasks(local_counter + 1)


            # elif (f"{local_counter + 2}" in tasks_sign_list[local_counter]):
            #     self.IterateTasks(local_counter + 2)


            # elif (f"{local_counter + 3}" in tasks_sign_list[local_counter]):
            #     self.IterateTasks(local_counter + 3)


            # elif (f"{local_counter + 4}" in tasks_sign_list[local_counter]):
            #     self.IterateTasks(local_counter + 4)


            # elif (f"{local_counter + n}" in tasks_sign_list[local_counter]):
            #     self.IterateTasks(local_counter + n)

                
            # else:
            #     print("dosnt exist!!!", "// local_counter:", local_counter)

            # local_counter += 1



                ### Concised version by using for loop (json file part)
# set a local Counter to iterate
        # local_counter = 0 
        # # Get the Max Count of the Tasks
        # if not tasks_sign_list:
        #     return
        # max_task_count = max(tasks_sign_list)
        # print("max value:", max_task_count)
        # # Get the actual <n> integer value
        # n = int(max_task_count[5])
        # print("Max tasks count:", n)

        # while local_counter < len(tasks_sign_list):
            
        #     found = False
        #     for i in range(n + 1):  # 检查连续的 <n> 个索引  //////////////////// working on /////////////////////////////

        #         # <+ 0~n> or <+i> offset
        #         if (f"{local_counter + i}" in tasks_sign_list[local_counter]):
        #             self.IterateTasks(local_counter + i)
        #             found = True
        #             break

        #         # <- 0~n> or <-i> offset
        #         elif (f"{local_counter - i}" in tasks_sign_list[local_counter]):
        #             self.IterateTasks(local_counter - i)
        #             found = True
        #             break

        #     if (not found):
        #         print("does not exist!!!", "// local_counter:", local_counter)

        #     local_counter += 1






list1 = ['111111', '111112', '111113', '1111110']

print(max(list1, key=len))

#!/usr/bin/python3
 
a = 10
def test():
    print(a)
test()
print(a)


x = (1, 2, 3)
y = (1, 2, 3)

print(x is y) # True，因为元组不可变；同等字符串，数字也一样

x = ([1])
y = ([1])

print(x is y) # False，因为x和y是两个不同的元组内嵌列表对象

x = 1; x2 = "ok"
y = 1; y2 = "ok"; z2 = "okay"

print(x is y, x2 is y2 is z2)

import numpy as np

A = np.array([[1, 2], [3, 4]])
B = np.array([[5, 6], [7, 8]])

C = A @ B  # 执行矩阵乘法运算
print(C)