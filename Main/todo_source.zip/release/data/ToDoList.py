from tkinter import ttk
from tkinter import *
import json


# !variables
# <_CONST> : Local constant
# <CONST> : Class global constant
# <Global_Variable> : Class global variable
# <local_variable> : Local variable

# !functions
# <GlobalFunction> : Global functions
# <StaticMethod> : Static class methods
# <Method> : Class methods


### Main UI
class UI:

    ## Main Global Variables
    # Main Global
    TASK_HEIGH = 27
    TASK_ITEMS = 3
    LIST_HEIGHT = TASK_HEIGH * TASK_ITEMS
    MAINFRAME_WIDGETS_HEIGHT = 54
    UPCONERHEIGHT = 19
    DRAWCOORDINATE = (0, 0)
    WINDOW_WIDTH = 400
    WINDOW_HEIGHT = 500

    # Main TEXT Dictionary for Labels
    TasksDict = {}
    DetailsDict = {}

    # Main Counter
    Counter = 0
    
    # Main Set for <serial_number> signs
    SignSet = set()

    # Main MEMORY Dictionary for Labels
    LabelDict_Tasks = {}
    LabelDict_Details = {}
    ButtonDict = {}

    # Window Status
    Status = [False, False, False]

    # Temperory Data for Saving Purpuse
    TempInfo = []

    # Tasks' Global Height for Determining ScrollRegion
    Global_Height = 1

    ## Main Scripts
    def __init__(self):

        # Main Root
        self.root = Tk()
        self.mainframe = Frame(self.root)
        self.mainframe.pack(expand=True, fill="both")
        self.root.title("ToDoList")
        self.X_Axis = (self.root.winfo_screenwidth() - self.WINDOW_WIDTH - 75) // 2
        self.Y_Axis = (self.root.winfo_screenheight() - self.WINDOW_HEIGHT - 50) // 2
        self.root.geometry(f"{self.WINDOW_WIDTH}x{self.WINDOW_HEIGHT}+{self.X_Axis}+{self.Y_Axis}")
        self.root.iconbitmap(r"data\icons\main.ico")

        # init files
        self.ImportJSON()
        
        # Fields
        self.field = ttk.Entry(self.mainframe, width=40)
        self.field.pack(anchor="center")

        # Buttons
        self.button = ttk.Button(self.mainframe, text="Done", command=self.DoneButton)
        self.button.pack(anchor="center")

        # Canvas
        self.canvas = Canvas(self.mainframe, scrollregion=(0, 0, self.mainframe.winfo_width(), self.Global_Height))
        self.canvas.pack(side="left", fill="both", expand=True)

        # first refresh
        self.new_frame = Frame(self.canvas) # creating new frames for refreshing window
        self.canvas.create_window(self.DRAWCOORDINATE, window=self.new_frame, anchor="nw", width=self.root.winfo_width() - self.UPCONERHEIGHT, height=self.Global_Height)
        self.InitAddTasks() # should use it after the frame is created

        # Slider 
        self.slider = ttk.Scrollbar(self.canvas, orient="vertical", command=self.canvas.yview)
        self.slider.pack(side="right", fill="y")

        # Configs 
        self.canvas.configure(yscrollcommand=self.slider.set)

        # bar 
        self.canvas.bind_all("<MouseWheel>", lambda event: self.canvas.yview_scroll(-int(event.delta / 60), "units"))
        self.Status[2] = True

        # resize the frame 
        self.mainframe.bind("<Configure>", lambda event: self.Resize(event))

        # Main Loop
        self.mainloop = mainloop()

        return

    ## 'Done' button's script (High degree of code coupling, bad code!)
    def DoneButton(self):

        # Scripts
        self.Resize(event=None) # counter added by 0
        self.Details() # counter added by 0

        return

    ## Ok button
    def OkButton(self, window):

        # add tasks global height
        self.Global_Height += self.LIST_HEIGHT

        # scripts
        self.Resize(event=None) # counter added by 0

        # local counter
        local_counter = 0

        # loop to find a position in <self.SignSet> to add tasks
        found = False
        while (not found):

            if (local_counter not in self.SignSet):

                # load Details
                self.DetailsDict[f"Detail_{local_counter}"] = self.detail_field.get()

                # Add tasks from the user input
                self.TasksDict[f"Task_{local_counter}"] = self.field.get() 

                # Tilte text
                self.LabelDict_Tasks[local_counter] = ttk.Label(self.new_frame, text=self.TasksDict[f"Task_{local_counter}"], font=("", 20))
                self.LabelDict_Tasks[local_counter].pack(anchor="w")

                # Details Text
                self.LabelDict_Details[local_counter] = ttk.Label(self.new_frame, text=self.DetailsDict[f"Detail_{local_counter}"])
                self.LabelDict_Details[local_counter].pack(anchor="w")

                # Finished Button
                self.ButtonDict[local_counter] = ttk.Button(self.new_frame, text=f"Finished", command=lambda: self.Finished(local_counter)) # DO NOT put global counter <self.Counter> in !!!
                self.ButtonDict[local_counter].pack(anchor="e")

                # add to the set
                self.SignSet.add(local_counter)

                # save as json
                self.ExportJson() # counter added by 0

                # founded
                found = True

            else:

                # looped once
                local_counter += 1

        # add counter by 1
        self.Counter += 1

        # destroy edit window
        window.destroy()
        self.Status[0] = False

        return

    ## Add tasks by looping through the data
    def InitAddTasks(self) -> dict:

        # define local tasks SignSet list 定义 局部任务导入标签
        tasks_sign_list = []
        # define local Details list 定义 局部注解(Details)导入标签
        details_sign_list = [] 

        # for looping through keys # for 循环 遍历tasks 序号
        for key in self.TasksDict.keys(): 
            tasks_sign_list.append(key)

        # for 循环 遍历Details 序号
        for key in self.DetailsDict.keys(): 
            details_sign_list.append(key)

        # check if tasks_sign_list empty
        if (not tasks_sign_list):
            return
        
        # Set a local Counter to iterate
        local_counter = 0
        
        # Get the Max Count of the Tasks, and we use only <tasks_sign_list>
        self.FindTasksMaximum(tasks_sign_list) # return the maximum task number

        # loop through data.json's tasks and add to <SignSet>
        for task in tasks_sign_list:
            self.SignSet.add(int(task[5:]))

        # Get the actual <n> integer value in the max_task string
        max_tasks_number = self.FindTasksMaximum(tasks_sign_list) + 1 # return the maximum task number

        # loop through whole tasks: <tasks_sign_list>
        while (local_counter < len(tasks_sign_list)):
            
            found = False
            for i in range(max_tasks_number):  # 检查连续的 <max_tasks_number> 个索引, 并根据索引 调整(adjust offset)其指向的值

                # <+ 0~max_tasks_number> or <+i> offset
                if (local_counter + i == int(tasks_sign_list[local_counter][5:])):
                    self.IterateTasks(local_counter + i)
                    found = True
                    break

                # <- 0~max_tasks_number> or <-i> offset
                elif (local_counter - i == int(tasks_sign_list[local_counter][5:])):
                    self.IterateTasks(local_counter - i)
                    found = True
                    break

            if (not found): pass

            # looped once
            local_counter += 1

        return

    ## Add widgets 添加组件 ；每次调用IterateTasks方法时，组件的内存空间被保持在 <LabelDict_Tasks> 等等的字典，并且次调用函数内存空间相隔离
    def IterateTasks(self, index): # 因为不同的组件被创建在不同的内存空间，所以说需要使用函数为介质来阻挡 for 循环在同一个 局部变量 内生成同一个内存空间的组件

        # Add to sign set
        self.SignSet.add(index)
        
        # Update Global_Height
        self.Global_Height += self.LIST_HEIGHT

        # Titles
        self.LabelDict_Tasks[index] = ttk.Label(self.new_frame, text=self.TasksDict[f"Task_{index}"], font=("", 20))
        self.LabelDict_Tasks[index].pack(anchor="w")
        
        # Details
        self.LabelDict_Details[index] = ttk.Label(self.new_frame, text=self.DetailsDict[f"Detail_{index}"])
        self.LabelDict_Details[index].pack(anchor="w"); 

        # change to serial number value (!meaningless)
        serial_number = index

        # 'Finished' button  # !tricky: the ttk.Button's 'command=' keyword argument will save the passing variable <serial_number> into memory, so it can basically remember the <serial_number>
        self.ButtonDict[index] = ttk.Button(self.new_frame, text=f"Finished", command=lambda: self.Finished(serial_number)) 
        self.ButtonDict[index].pack(anchor="e")

        # Add iteration by 1
        self.Counter += 1

        return

    # 'Finished' button's script
    def Finished(self, serial_number):

        # Comfirm Window
        if self.Status[1] == False:

            # main Comfirm Window
            top = Toplevel(self.root)
            top.resizable(False, False)
            top.title("Check")
            top.wm_attributes("-topmost", True)
            top.geometry(f"+{self.X_Axis + 70}+{self.Y_Axis + 140}")
            top.protocol("WM_DELETE_WINDOW", lambda: self.Close(top, 1))
            top.iconbitmap(r"data\icons\check.ico")
            t = ttk.Label(top, text="Confirm?", font=20, padding=30, width=20, anchor="center")
            t.pack()
            b1 = ttk.Button(top, text="Yes", command=lambda: self.DestroyScript(top, 1, serial_number)) # DestroyScript subtracted counter by 1
            b2 = ttk.Button(top, text="No", command=lambda: self.Close(top, 1))
            b1.pack()
            b2.pack()
            self.Status[1] = True

        else:

            pass

        return

    # destroy things 'Finished' button's script
    def DestroyScript(self, window, member, serial_number):
    
        # subtract by task height
        self.Global_Height -= self.LIST_HEIGHT

        # Scripts
        self.Resize(event=None) # added counter by 0
        self.UpdateCanvasHeight()  # added counter by 0
        self.ImportJSON() # added counter by 0
        self.DeleteJSON(serial_number) # added counter by 0

        # close the window
        self.Close(window, member)
        
        # destroy lot of things
        self.LabelDict_Tasks[serial_number].destroy()
        self.LabelDict_Details[serial_number].destroy()
        self.ButtonDict[serial_number].destroy()

        # delete the sign in <self.SignSet>
        self.SignSet.remove(serial_number)

        # subtract counter by 1
        self.Counter -= 1

        return

    # details window
    def Details(self):

        if (self.Status[0] == False):

            # main details window
            self.details_top = Toplevel(self.root)
            self.details_top.resizable(False, False)
            self.details_top.geometry(f"+{self.X_Axis + 60}+{self.Y_Axis + 140}")
            self.details_top.protocol("WM_DELETE_WINDOW", lambda: self.Close(self.details_top, 0))
            self.details_top.iconbitmap(r"data\icons\edit.ico")
            self.details_top.title("Editing Details")
            self.detail_field = ttk.Entry(self.details_top, width=40)
            details_button = ttk.Button(self.details_top, text="Ok", command=lambda: self.OkButton(self.details_top))
            self.detail_field.pack()
            details_button.pack()
            self.Status[0] = True

        else:
            
            # lift up the window
            self.details_top.lift()

        return

    # refreshing the Details for editing (0 reference)
    def RefreshDetails(self):

        self.field.destroy()
        new_Details_field = ttk.Label(self.mainframe, text=self.DetailsDict)
        new_Details_field.pack(anchor="w")

        return new_Details_field

    # main resize
    def Resize(self, event):

        if (event == None): # 静态时

            # 窗口大于任务栏长度, 任务栏不可以滑动
            if (self.Global_Height <= self.canvas.winfo_height()):  
                self.ResizeScript_static()

            # 窗口小于任务栏长度，任务栏可以滑动
            elif (self.Global_Height > self.canvas.winfo_height()):
                self.ResizeScript_moving() 

        else: # 活动时

            # 窗口大于任务栏长度，任务栏不可以滑动
            if (self.Global_Height <= self.mainframe.winfo_height() - self.MAINFRAME_WIDGETS_HEIGHT):
                self.ResizeScript_static(event)

            # 窗口小于任务栏长度，任务栏可以滑动
            elif (self.Global_Height > self.mainframe.winfo_height() - self.MAINFRAME_WIDGETS_HEIGHT): 
                self.ResizeScript_moving(event)
                
        return

    # basically just drawing a new frame on top of the previous frame on the canvas (!brutal)
    def CreateNewFrame(self, event):

        # static
        if (event == None): 

            self.canvas.create_window(
                self.DRAWCOORDINATE, 
                window=self.new_frame, 
                anchor="nw", 
                width=self.mainframe.winfo_width() - self.UPCONERHEIGHT, 
                height=self.Global_Height
            )

        # moving
        else:

            self.canvas.create_window(
                self.DRAWCOORDINATE, 
                window=self.new_frame, 
                anchor="nw", 
                width=event.width - self.UPCONERHEIGHT, 
                height=self.Global_Height
            )

        return

    # update the scrollbar depending on the tasks
    def UpdateCanvasHeight(self, static=False): 

        # 重新配置 Canvas 的大小
        self.canvas.update_idletasks()

        # 更新 Canvas 的滚动区域
        if (static):

            # weird thingy, i have to set the scrollregion's height to <self.canvas.winfo_height()-4> to get actual suiting static state
            self.canvas.config(scrollregion=(0, 0, self.canvas.winfo_width(), self.canvas.winfo_height()-4)) 
                
        else:

            # main scrollbar control
            self.canvas.config(scrollregion=(0, 0, self.canvas.winfo_width(), self.Global_Height))

        return

    # closing windows and update Status 
    def Close(self, window=None, member=None):

        # check whether it is actually opening
        if (window == None):

            # change state
            self.Status[member] = False

        else:
            # close the window
            window.destroy()

            # change state
            self.Status[member] = False

        return
    
    # create json file
    def CreateJSON(self):

        with (open(r"data\data.json", "w", encoding="UTF-8")) as file:
            
            file.write("hi")

        return

    # save the file in json format
    def ExportJson(self):

        with (open(r"data\data.json", "w", encoding="UTF-8")) as file:

            json.dump((self.DetailsDict, self.TasksDict), file, ensure_ascii=False, indent=4)

        return

    # emport data.json file
    def ImportJSON(self):

        try:

            with (open(r"data\data.json", "rt", encoding="UTF-8")) as file:
                
                try:
                    # load initial data.json
                    self.data = json.load(file)

                    # add inital stored data
                    self.DetailsDict = self.data[0]
                    self.TasksDict = self.data[1]

                except json.decoder.JSONDecodeError:

                    print("NO DATA CURRENTLY!!!")

        except FileNotFoundError:
            print("creating data...")
            self.CreateJSON()

            return

    # export data.json file
    def DeleteJSON(self, serial_number):

        # create a temporary object to store
        self.TempInfo = self.data[:]

        # value assignment; unziping the list
        details_dict_local = self.TempInfo[0]
        tasksdict_local = self.TempInfo[1]

        # delete specific task depend on <serial_number>
        details_dict_local.pop(f"Detail_{serial_number}")
        tasksdict_local.pop(f"Task_{serial_number}")

        # dump temp into data.json
        with open(r"data\data.json", "w", encoding="UTF-8") as file:

            json.dump(self.TempInfo, file, ensure_ascii=False, indent=4)
        
        return

    # static resizing the window
    def ResizeScript_static(self, event=None):

        self.canvas.delete("all")
        
        # statically create a new frame on top on the canvas (!brutal)
        self.CreateNewFrame(event)

        # update for scrollbar linking
        self.UpdateCanvasHeight(static=True)

        # unbind mouse wheel
        self.canvas.unbind_all("<MouseWheel>")
        self.Status[2] = False

        return
    
    # dynamic resizing the window
    def ResizeScript_moving(self, event=None):

        self.canvas.delete("all")

        # dynamically create a new frame on top on the canvas (!brutal)
        self.CreateNewFrame(event)

        # update for scrollbar linking
        self.UpdateCanvasHeight(static=False)


        # bind mouse wheel (!costing memory) -> solved
        # check the state to avoid memory consumption
        if (self.Status[2] == False):

            self.canvas.bind_all("<MouseWheel>", lambda event: self.canvas.yview_scroll(-int(event.delta / 60), "units")) 
            self.Status[2] = True

        else:

            return
        
        return
    
    # finding the maximum value of the tasks list
    def FindTasksMaximum(self, tasks_list: list) -> int:

        # to store tasks' serial numbers
        local_tasks_set = set()

        # go through the whole list
        for task in tasks_list:
            local_tasks_set.add(int(task[5:]))

        # get the maximum value
        max_task_value = max(local_tasks_set)
        
        # return the maximum value
        return max_task_value


if __name__ == "__main__":
    UI()