from tkinter import ttk
from tkinter import *
import json


# !variables
# <_CONST> : protected constant
# <__CONST> : private constant
# <CONST> : Class global constant
# <Global_Variable> : Class global variable
# <local_variable> : Local variable

# !functions
# <global_function> : Global functions
# <static_method> : Static class methods
# <method> : Class methods


### Main UI
class UI:

    ## Main Global Variables
    # Main Global constants
    TASK_HEIGH = 26.5
    TASK_ITEMS = 3
    LIST_HEIGHT = TASK_HEIGH * TASK_ITEMS
    MAINFRAME_WIDGETS_HEIGHT = 54
    UPCONER_HEIGHT = 19
    DRAW_COORDINATE = (0, 0)
    WINDOW_WIDTH = 400
    WINDOW_HEIGHT = 500
    TIME = 0

    # Main TEXT Dictionary for Labels
    TasksDict = {}
    DetailsDict = {}

    # Main Counter
    Counter = 0
    
    # Main Set for <serial_number> signs
    SignSet = set()

    # Main MEMORY Dictionary for Labels
    LabelDict_Tasks = {}
    LabelDict_Details = {}
    ButtonDict = {}

    # messy Status
    Status = [False, False, False, False, False, False]

    # Temperory Data for Saving Purpuse
    TempInfo = []

    # Tasks' Global Height for Determining ScrollRegion
    Global_Height = 1

    ## ui.py
    def __init__(self, root):
        '''main root window

        initialize everything
        '''
        # Main Root
        self.root = root
        self.root.resizable(False, False)
        self.mainframe = Frame(self.root)
        self.mainframe.pack(expand=True, fill="both")
        self.root.title("ToDoList")
        self.X_Axis = (self.root.winfo_screenwidth() - self.WINDOW_WIDTH - 75) // 2
        self.Y_Axis = (self.root.winfo_screenheight() - self.WINDOW_HEIGHT - 50) // 2
        self.root.geometry(f"{self.WINDOW_WIDTH}x{self.WINDOW_HEIGHT}+{self.X_Axis}+{self.Y_Axis}")
        self.root.iconbitmap(r"data\icons\main.ico")

        # init files
        self.import_json()
        
        # Fields
        self.field = ttk.Entry(self.mainframe, width=40)
        self.field.pack(anchor="center")

        # Buttons
        self.button = ttk.Button(self.mainframe, text="Done", command=self.details)
        self.button.pack(anchor="center")

        # Canvas
        self.canvas = Canvas(self.mainframe, highlightthickness=0, scrollregion=(0, 0, self.mainframe.winfo_width(), self.Global_Height))
        self.canvas.pack(side="left", fill="both", expand=True)
        
        # slider
        self.slider_x = 1.1
        self.x_accelerate = 0.00014
        self.x_velocity = 0.00545
        self.slider = ttk.Scrollbar(self.canvas, orient="vertical", command=self.canvas.yview)
        self.slider.place(relx=self.slider_x, rely=0.5, anchor="e")

        # first refresh
        self.new_frame = Frame(self.canvas) # creating new frames for refreshing window
        self.init_add_tasks() # should use it after the frame is created
        self.canvas.create_window(self.DRAW_COORDINATE, window=self.new_frame, anchor="nw", width=self.root.winfo_width(), height=self.root.winfo_height())
        self.resize(None)

        # Configs 
        self.canvas.configure(yscrollcommand=self.slider.set)

        # bar 
        self.canvas.bind_all("<MouseWheel>", lambda event: self.canvas.yview_scroll(-int(event.delta / 60), "units"))
        self.Status[2] = True

        # resize the frame 
        # self.mainframe.bind("<Configure>", lambda event: self.resize(event))

        # Main Loop
        self.mainloop = mainloop()
    

    ### ------------------------------------------------------------------------------------------------animation.py

    def move_button(self, button, button_relx, button_rely, status):
        '''
        moves the buttons
        '''
        # print(button_rely)
        if 0 < button_relx and status == "hide":
            button_relx -= 0.1
            button.place(relx=button_relx, rely=button_rely) # wanted to get the exact y location of the button widget. -> solved
            self.root.after(10, lambda: self.move_button(button, button_relx, button_rely, status="hide"))
        elif 0 <= button_relx < 0.78 and status == "appear":
            button_relx += 0.1
            button.place(relx=button_relx, rely=button_rely)
            self.root.after(20, lambda: self.move_button(button, button_relx, button_rely, status="appear"))
        else:
            if round(button_relx) == 1:
                button.pack(anchor="e")
            else:
                # print("destroyed")
                button.destroy()



    def move_label(self, label, label_relx, label_rely, status): 
        '''moves the labels
        
        using after
        '''
        if -1 <= label_relx < 0 and status == "appear":
            label_relx += 0.1
            label.place(relx=label_relx, rely=label_rely)
            self.root.after(10, lambda: self.move_label(label, label_relx, label_rely, status="appear"))
        elif -1 < label_relx and status == "hide":
            label_relx -= 0.1
            label.place(relx=label_relx, rely=label_rely)
            self.root.after(10, lambda: self.move_label(label, label_relx, label_rely, status="hide"))
        else:
            # print(label_relx)
            if round(label_relx) == 0:
                label.pack(anchor="w")
            else:
                label.destroy()


    ### animation.py
    def move_slider(self): # 4 2
        '''appears the slider

        using after
        '''
        __DELTA_TIME = 1

        if self.Status[4] == True:
            return

        if 1.0 <= self.slider_x <= 1.1 and self.x_velocity >= 0: # const <self.slider_x> var <self.acc> <self.velo>
            self.TIME += 1
            self.x_velocity -= self.x_accelerate * __DELTA_TIME
            self.slider_x -= self.x_velocity * __DELTA_TIME # s = (v + a * dt) * dt
            self.slider.place(relx=self.slider_x, rely=0.5, relheight=1)
            self.root.after(15, self.move_slider)
        else:
            self.slider_x = 1 # float numbers are not accurate (!facepalm)
            self.Status[3] = False
            self.Status[4] = True
            self.x_velocity = 0.00545



    def move_slider_hide(self): # 3 1
        '''
        hides the slider
        '''
        __DELTA_TIME = 1

        if self.Status[3] == True:
            return

        if 1.0 <= self.slider_x <= 1.1:
            self.TIME += 1
            self.slider_x += (self.x_velocity - (self.x_accelerate * __DELTA_TIME)) * __DELTA_TIME
            self.slider.place(relx=self.slider_x, rely=0.5, relheight=1)
            self.root.after(20, self.move_slider_hide)
        else:
            self.slider_x = 1.1
            self.x_velocity = 0.00545
            self.Status[4] = False
            self.Status[3] = True



    ### ------------------------------------------------------------------------------------------------animation.py



    ### ------------------------------------------------------------------------------------------------ui.py

    ## Ok button
    def ok_button(self, window):
        '''
        scripts that create task
        '''
        # add tasks global height
        self.Global_Height += self.LIST_HEIGHT

        # scripts
        self.resize(event=None) # counter added by 0

        # local counter
        local_counter = 0
        
        # loop to find a position in <self.SignSet> to add tasks
        found = False
        while not found:
            if local_counter not in self.SignSet:
                # load Details
                self.DetailsDict[f"Detail_{local_counter}"] = self.edit_window.detail_field.get()

                # Add tasks from the user input
                self.TasksDict[f"Task_{local_counter}"] = self.field.get() 

                # finished Button
                self.ButtonDict[local_counter] = ttk.Button(self.new_frame, text=f"finished", command=lambda: self.finished(local_counter)) # DO NOT put global variables in
                # self.ButtonDict[local_counter].pack(anchor="e")
                self.move_button(self.ButtonDict[local_counter], 0,  (self.Global_Height - 30) / 500, status="appear") # problem: button_y = (self.Global_Height - 60) / 500
                
                # Tilte text
                self.LabelDict_Tasks[local_counter] = ttk.Label(self.new_frame, text=self.TasksDict[f"Task_{local_counter}"], font=("", 20))
                # self.LabelDict_Tasks[local_counter].pack(anchor="w")
                self.move_label(self.LabelDict_Tasks[local_counter], -1, (self.Global_Height - 50) / 500, status="appear")

                # Details Text
                self.LabelDict_Details[local_counter] = ttk.Label(self.new_frame, text=self.DetailsDict[f"Detail_{local_counter}"])
                # self.LabelDict_Details[local_counter].pack(anchor="w")
                self.move_label(self.LabelDict_Details[local_counter], -1, (self.Global_Height - 50) / 500, status="appear")

                # add to the set
                self.SignSet.add(local_counter)

                # save as json
                self.export_json() # counter added by 0

                # founded
                found = True
            else:
                # looped once
                local_counter += 1

        # add counter by 1
        self.Counter += 1

        # destroy edit window
        window.destroy()
        self.Status[0] = False
    


    # 'finished' button's window
    def finished(self, serial_number):
        '''check whether window
        
        ConfirmWindow Class create a toplevel window
        '''
        # Confirm Window
        if self.Status[1] == False:
            self.confirm_window = ConfirmWindow(self.Status, self.root, self.Y_Axis, self.X_Axis, self.close, self.destroy_script, serial_number)
        else:
            # reflections
            self.confirm_window.confirm_top.bell()
            self.confirm_window.confirm_top.focus_set()



    # details window
    def details(self):
        '''edit detail window

        EditWindow Class creates a editing window
        '''
        if self.Status[0] == False:
            self.edit_window = EditWindow(self.root, self.X_Axis, self.Y_Axis, self.close, self.ok_button, self.Status)           
        else:
            # lift up the window focus some stuff
            self.edit_window.details_top.bell()
            self.edit_window.details_top.focus_set()



    ### script.py -- animation.py
    # destroy things 'finished' button's script
    def destroy_script(self, window, member, serial_number):
        '''
        scripts that remove things
        '''
        # subtract by task height
        self.Global_Height -= self.LIST_HEIGHT

        # Scripts
        self.resize(event=None)
        self.update_canvas_height()
        self.import_json()
        self.delete_json(serial_number)
        self.move_button(self.ButtonDict[serial_number], 1, self.ButtonDict[serial_number].winfo_y() / 500, status="hide")
        self.move_label(self.LabelDict_Tasks[serial_number], 0, self.LabelDict_Tasks[serial_number].winfo_y() / 500, status="hide")
        self.move_label(self.LabelDict_Details[serial_number], 0, self.LabelDict_Details[serial_number].winfo_y() / 500, status="hide")

        # close the window
        self.close(window, member)

        # delete the sign in <self.SignSet>
        self.SignSet.remove(serial_number)

        # subtract counter by 1
        self.Counter -= 1



    ### ------------------------------------------------------------------------------------------------ui.py



    ### script.py
    # closing windows and update Status 
    def close(self, window=None, member=None):
        '''
        close window
        '''
        # check whether it is actually opening
        if window == None:
            # change state
            self.Status[member] = False
        else:
            # close the window
            window.destroy()
            # change state
            self.Status[member] = False
    

    ### ------------------------------------------------------------------------------------------------initial.py

    ## Add tasks by looping through the data
    def init_add_tasks(self) -> dict:
        '''
        iterate for adding tasks
        '''
        # define local tasks SignSet list 定义 局部任务导入标签
        tasks_sign_list = []
        # define local Details list 定义 局部注解(Details)导入标签
        details_sign_list = [] 
        # Set a local Counter to iterate
        local_counter = 0

        # for looping through keys # for 循环 遍历tasks 序号
        for key in self.TasksDict.keys(): 
            tasks_sign_list.append(key)
        # for 循环 遍历Details 序号
        for key in self.DetailsDict.keys(): 
            details_sign_list.append(key)
        # check if tasks_sign_list empty
        if not tasks_sign_list:
            return
        
        # Get the Max Count of the Tasks, and we use only <tasks_sign_list>
        self.find_tasks_maximum(tasks_sign_list) # return the maximum task number

        # loop through data.json's tasks and add to <SignSet>
        for task in tasks_sign_list:
            self.SignSet.add(int(task[5:]))

        # Get the actual <n> integer value in the max_task string
        max_tasks_number = self.find_tasks_maximum(tasks_sign_list) + 1 # return the maximum task number

        # loop through whole tasks: <tasks_sign_list>
        while local_counter < len(tasks_sign_list):
            found = False
            for i in range(max_tasks_number):  # 检查连续的 <max_tasks_number> 个索引, 并根据索引 调整(adjust offset)其指向的值
                # <+ 0~max_tasks_number> or <+i> offset
                if local_counter + i == int(tasks_sign_list[local_counter][5:]):
                    self.create_initial_task(local_counter + i)
                    found = True
                    break
                # <- 0~max_tasks_number> or <-i> offset
                elif local_counter - i == int(tasks_sign_list[local_counter][5:]):
                    self.create_initial_task(local_counter - i)
                    found = True
                    break
            if not found: print("Some weird thing happened ,you forgot your coffee") 
            # looped once
            local_counter += 1
        return


    ## Add widgets 添加组件 ；每次调用 create_initial_task 方法时，组件的内存空间被保持在 <LabelDict_Tasks> 等等的字典，并且次调用函数内存空间相隔离
    def create_initial_task(self, index): # 因为不同的组件被创建在不同的内存空间，所以说需要使用函数为介质来阻挡 for 循环在同一个 局部变量 内生成同一个内存空间的组件
        '''create initial tasks

        by placing it onto the frame
        '''
        # Add to sign set
        self.SignSet.add(index)
        
        # Update Global_Height
        self.Global_Height += self.LIST_HEIGHT

        # Titles
        self.LabelDict_Tasks[index] = ttk.Label(self.new_frame, text=self.TasksDict[f"Task_{index}"], font=("", 20))
        self.LabelDict_Tasks[index].pack(anchor="w")
        
        # Details
        self.LabelDict_Details[index] = ttk.Label(self.new_frame, text=self.DetailsDict[f"Detail_{index}"])
        self.LabelDict_Details[index].pack(anchor="w"); 

        # change to serial number var (!meaningless)
        serial_number = index

        # 'finished' button  # !tricky: the ttk.Button's 'command=' keyword argument will save the passing variable <serial_number> into memory, so it can basically remember the <serial_number>
        # button_x = 0
        self.ButtonDict[index] = ttk.Button(self.new_frame, text=f"finished", command=lambda: self.finished(serial_number))
        self.ButtonDict[index].pack(anchor="e")
        # self.move_button(self.ButtonDict[index], button_x)

        # Add iteration by 1
        self.Counter += 1


    # create json file
    def create_json(self):
        with open(r"data\data.json", "w", encoding="UTF-8") as file:
            file.write("hi")


    # save the file in json format
    def export_json(self):
        with open(r"data\data.json", "w", encoding="UTF-8") as file:
            json.dump((self.DetailsDict, self.TasksDict), file, ensure_ascii=False, indent=4)


    # import data.json file
    def import_json(self):
        try:
            with open(r"data\data.json", "rt", encoding="UTF-8") as file:             
                try:
                    # load initial data.json
                    self.data = json.load(file)
                    # add inital stored data
                    self.DetailsDict = self.data[0]
                    self.TasksDict = self.data[1]
                except json.decoder.JSONDecodeError:
                    pass
        except FileNotFoundError:
            # create a new one
            self.create_json()


    # delete data.json datas
    def delete_json(self, serial_number):
        # create a temporary object to store
        self.TempInfo = self.data[:]

        # value assignment; unziping the list
        details_dict_local = self.TempInfo[0]
        tasksdict_local = self.TempInfo[1]

        # delete specific task depend on <serial_number>
        details_dict_local.pop(f"Detail_{serial_number}")
        tasksdict_local.pop(f"Task_{serial_number}")

        # dump temp into data.json
        with open(r"data\data.json", "w", encoding="UTF-8") as file:
            json.dump(self.TempInfo, file, ensure_ascii=False, indent=4)
        
    ### ------------------------------------------------------------------------------------------------initial.py



    ### ------------------------------------------------------------------------------------------------resize.py

    # update the scrollbar depending on the tasks
    def update_canvas_height(self, static=False):
        # 更新 Canvas 的滚动区域
        if static:
            # weird thingy, i have to set the scrollregion's height to <self.canvas.winfo_height()-4> to get actual suiting static state
            self.canvas.config(scrollregion=(0, 0, self.canvas.winfo_width(), self.canvas.winfo_height()-4))       
        else:
            # main scrollbar control
            self.canvas.config(scrollregion=(0, 0, self.canvas.winfo_width(), self.Global_Height))


    # basically just drawing a new frame on top of the previous frame on the canvas (!brutal)
    def create_new_frame(self, event):
        # static
        # if event == None: 
        self.canvas.create_window(
            self.DRAW_COORDINATE, 
            window=self.new_frame, 
            anchor="nw", 
            width=self.root.winfo_width() - self.UPCONER_HEIGHT, 
            height=self.Global_Height
        )
        # moving
        # else:
        #     self.canvas.create_window(
        #         self.DRAW_COORDINATE, 
        #         window=self.new_frame, 
        #         anchor="nw", 
        #         width=event.width - self.UPCONER_HEIGHT, 
        #         height=self.Global_Height
        #     )


    # main resize
    def resize(self, event):
        # if event == None: # 静态时
        # 窗口大于任务栏长度, 任务栏不可以滑动
        if self.Global_Height <= 450:
            # print("_1", self.Global_Height)
            self.resize_script_static()
            # self.create_new_frame()
            self.move_slider_hide()
        # 窗口小于任务栏长度，任务栏可以滑动
        elif self.Global_Height > 450:
            # print("_2", self.Global_Height)
            self.resize_script_moving()
            # self.create_new_frame(None)
            self.move_slider()
        # else: # 活动时
        #     # 窗口大于任务栏长度，任务栏不可以滑动
        #     if self.Global_Height <= self.mainframe.winfo_height() - self.MAINFRAME_WIDGETS_HEIGHT:
        #         print("_3")
        #         self.resize_script_static()
        #         self.move_slider_hide()
        #     # 窗口小于任务栏长度，任务栏可以滑动
        #     elif self.Global_Height > self.mainframe.winfo_height() - self.MAINFRAME_WIDGETS_HEIGHT:
        #         print("_4")
        #         self.resize_script_moving()
        #         self.move_slider()


    # static resizing the window
    def resize_script_static(self, event=None):
        # release memory
        # self.canvas.delete("all")
        
        # statically create a new frame on top on the canvas (!brutal)
        # self.create_new_frame(event)
        self.canvas.create_window(self.DRAW_COORDINATE, window=self.new_frame, anchor="nw", width=self.root.winfo_width(), height=self.root.winfo_height())

        # update for scrollbar linking
        self.update_canvas_height(static=True)

        # unbind mouse wheel
        self.canvas.unbind_all("<MouseWheel>")
        self.Status[2] = False

    
    # dynamic resizing the window
    def resize_script_moving(self, event=None):
        # release memory
        # self.canvas.delete("all")

        if self.Status[5] == False:
            # dynamically create a new frame on top on the canvas (!brutal)
            self.create_new_frame(event)
            # update for scrollbar linking
            self.update_canvas_height(static=False)

        # bind mouse wheel (!costing memory) -> solved
        # check the state to avoid memory consumption
        if self.Status[2] == False:
            # mouse wheel bind
            self.canvas.bind_all("<MouseWheel>", lambda event: self.canvas.yview_scroll(-int(event.delta / 60), "units")) 
            self.Status[2] = True
        else:
            return

    ### ------------------------------------------------------------------------------------------------resize.py


    ### script.py
    # finding the maximum value of the tasks list
    def find_tasks_maximum(self, tasks_list: list) -> int:

        # to store tasks' serial numbers
        local_tasks_set = set()

        # go through the whole list
        for task in tasks_list:
            local_tasks_set.add(int(task[5:]))

        # get the maximum value
        max_task_value = max(local_tasks_set)
        
        # return the maximum value
        return max_task_value


class EditWindow:
    def __init__(self, root, x_axis, y_axis, close_function, ok_button_function, status) -> None:
        self.root = root
        self.X_Axis = x_axis
        self.Y_Axis = y_axis
        self.close = close_function
        self.ok_button = ok_button_function
        self.Status = status

        # main details window
        self.details_top = Toplevel(self.root)
        self.details_top.resizable(False, False)
        self.details_top.geometry(f"+{self.X_Axis + 60}+{self.Y_Axis + 140}")
        self.details_top.protocol("WM_DELETE_WINDOW", lambda: self.close(self.details_top, 0))
        self.details_top.iconbitmap(r"data\icons\edit.ico")
        self.details_top.title("Editing Details")
        self.detail_field = ttk.Entry(self.details_top, width=40)
        self.details_button = ttk.Button(self.details_top, text="Ok", command=lambda: self.ok_button(self.details_top))
        self.detail_field.pack()
        self.details_button.pack()
        self.Status[0] = True


class ConfirmWindow:
    def __init__(self, status, root, y_axis, x_axis, close_function, destroy_function, serial_number) -> None:
        self.Status = status
        self.root = root
        self.Y_Axis = y_axis
        self.X_Axis = x_axis
        self.close = close_function
        self.destroy_script = destroy_function
        self.serial_number = serial_number

        # main Comfirm Window
        self.confirm_top = Toplevel(self.root)
        self.confirm_top.resizable(False, False)
        self.confirm_top.title("Check")
        self.confirm_top.wm_attributes("-topmost", True)
        self.confirm_top.geometry(f"+{self.X_Axis + 70}+{self.Y_Axis + 140}")
        self.confirm_top.protocol("WM_DELETE_WINDOW", lambda: self.close(self.confirm_top, 1))
        self.confirm_top.iconbitmap(r"data\icons\check.ico")
        t = ttk.Label(self.confirm_top, text="Confirm?", font=20, padding=30, width=20, anchor="center")
        b1 = ttk.Button(self.confirm_top, text="Yes", command=lambda: self.destroy_script(self.confirm_top, 1, self.serial_number)) # destroy_script subtracted counter by 1
        b2 = ttk.Button(self.confirm_top, text="No", command=lambda: self.close(self.confirm_top, 1))
        t.pack()
        b1.pack()
        b2.pack()
        self.Status[1] = True
