from tkinter import *
from tkinter import ttk


class EditWindow:
    def __init__(self, root, x_axis, y_axis, close_function, ok_button_function, status) -> None:
        self.root = root
        self.X_Axis = x_axis
        self.Y_Axis = y_axis
        self.close = close_function
        self.ok_button = ok_button_function
        self.Status = status

        # main details window
        self.details_top = Toplevel(self.root)
        self.details_top.resizable(False, False)
        self.details_top.geometry(f"+{self.X_Axis + 60}+{self.Y_Axis + 140}")
        self.details_top.protocol("WM_DELETE_WINDOW", lambda: self.close(self.details_top, 0))
        self.details_top.iconbitmap(r"data\icons\edit.ico")
        self.details_top.title("Editing Details")
        self.detail_field = ttk.Entry(self.details_top, width=40)
        self.details_button = ttk.Button(self.details_top, text="Ok", command=lambda: self.ok_button(self.details_top))
        self.detail_field.pack()
        self.details_button.pack()
        self.Status[0] = True