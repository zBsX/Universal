from tkinter import *
from tkinter import ttk


class ConfirmWindow:
    def __init__(self, status, root, y_axis, x_axis, close_function, destroy_function, serial_number) -> None:
        self.Status = status
        self.root = root
        self.Y_Axis = y_axis
        self.X_Axis = x_axis
        self.close = close_function
        self.destroy_script = destroy_function
        self.serial_number = serial_number

        # main Comfirm Window
        self.confirm_top = Toplevel(self.root)
        self.confirm_top.resizable(False, False)
        self.confirm_top.title("Check")
        self.confirm_top.wm_attributes("-topmost", True)
        self.confirm_top.geometry(f"+{self.X_Axis + 70}+{self.Y_Axis + 140}")
        self.confirm_top.protocol("WM_DELETE_WINDOW", lambda: self.close(self.confirm_top, 1))
        self.confirm_top.iconbitmap(r"data\icons\check.ico")
        t = ttk.Label(self.confirm_top, text="Confirm?", font=20, padding=30, width=20, anchor="center")
        b1 = ttk.Button(self.confirm_top, text="Yes", command=lambda: self.destroy_script(self.confirm_top, 1, self.serial_number)) # destroy_script subtracted counter by 1
        b2 = ttk.Button(self.confirm_top, text="No", command=lambda: self.close(self.confirm_top, 1))
        t.pack()
        b1.pack()
        b2.pack()
        self.Status[1] = True
