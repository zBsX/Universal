from data import main_ui
import tkinter as tk

root = tk.Tk()
main_ui.UI(root)
